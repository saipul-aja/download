<?php
$emailku ='reditscdinofames@gmail.com'; // GANTI EMAIL KAMU DISINI
?>