<?php 

if(isset($_POST['userId']) || isset($_POST['zoneId'])) {
    $userId = $_POST['userId'];
    $zoneId = $_POST['zoneId'];
    $apiUrl = "https://api.ryucodex.com/idMl/".$userId.".".$zoneId;
    
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $apiUrl);
    curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($curl, CURLOPT_HEADER, 0);
    $dataId = curl_exec($curl);
    curl_close($curl);
    
    print_r(urldecode($dataId));  
}

?>